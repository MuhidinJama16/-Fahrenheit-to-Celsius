document.getElementById('convert-btn').addEventListener('click', convTotal)

// Event Function
function convTotal() {
    let fahrenheit = Number(document.getElementById('f-input').value);

    console.log(fahrenheit);
    console.log(typeof(fahrenheit));


    let total = (fahrenheit - 32) * 5 / 9;

    document.getElementById('result').innerHTML = total;
}